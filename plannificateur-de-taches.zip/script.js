import { supabaseManager } from './supabaseClient.js';

export class TaskManager {
    constructor() {
        this.tasks = [];
        this.collaborators = [];
        this.pendingInvites = [];
        this.taskForm = document.getElementById('taskForm');
        this.tasksList = document.getElementById('tasksList');
        this.statusFilter = document.getElementById('statusFilter');
        this.priorityFilter = document.getElementById('priorityFilter');
        this.ganttTimeline = document.getElementById('ganttTimeline');
        this.ganttBody = document.getElementById('ganttBody');
        this.collaboratorsList = document.getElementById('collaboratorsList');
        this.pendingInvitesList = document.getElementById('pendingInvites');
        this.inviteButton = document.getElementById('inviteButton');
        this.inviteEmail = document.getElementById('inviteEmail');

        this.initializeEventListeners();
    }

    initializeEventListeners() {
        // Gestion du formulaire d'ajout de tâche
        this.taskForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.addTask();
        });

        // Gestion des filtres
        this.statusFilter.addEventListener('change', () => this.renderTasks());
        this.priorityFilter.addEventListener('change', () => this.renderTasks());

        // Gestion des invitations
        this.inviteButton.addEventListener('click', () => this.inviteCollaborator());

        // Mise à jour du sélecteur de collaborateurs quand la liste change
        this.renderAssigneeSelect();
    }

    renderAssigneeSelect() {
        const assignToSelect = document.getElementById('assignTo');
        if (!assignToSelect) return;

        assignToSelect.innerHTML = this.collaborators.map(collaborator => `
            <option value="${collaborator.id}">
                ${collaborator.name} (${collaborator.email})
            </option>
        `).join('');
    }

    // Méthodes de gestion des collaborateurs
    async inviteCollaborator() {
        const email = this.inviteEmail.value.trim();
        if (!email) return;

        if (!this.isValidEmail(email)) {
            alert('Veuillez entrer une adresse email valide');
            return;
        }

        const { error } = await supabaseManager.sendInvitation(email);
        
        if (error) {
            if (error.code === '23505') { // Code d'erreur unique constraint
                alert('Une invitation a déjà été envoyée à cette adresse');
            } else {
                alert('Erreur lors de l\'envoi de l\'invitation');
                console.error('Error sending invitation:', error);
            }
            return;
        }

        this.inviteEmail.value = '';
        await this.loadInvitations();
    }

    async removeInvite(inviteId) {
        const { error } = await supabaseManager.updateInvitationStatus(inviteId, 'cancelled');
        if (error) {
            console.error('Error cancelling invitation:', error);
            return;
        }
        await this.loadInvitations();
    }

    async acceptInvite(inviteId) {
        const { error } = await supabaseManager.updateInvitationStatus(inviteId, 'accepted');
        if (error) {
            console.error('Error accepting invitation:', error);
            return;
        }
        await this.loadInvitations();
        await this.loadCollaborators();
    }

    async removeCollaborator(collaboratorId) {
        // Supprimer toutes les assignations de tâches pour ce collaborateur
        const { error: assignmentError } = await supabaseManager.supabase
            .from('task_assignments')
            .delete()
            .eq('user_id', collaboratorId);

        if (assignmentError) {
            console.error('Error removing task assignments:', assignmentError);
            return;
        }

        await this.loadTasks();
        await this.loadCollaborators();
    }

    // Méthodes de rendu
    renderCollaborators() {
        if (!this.collaboratorsList) return;

        this.collaboratorsList.innerHTML = this.collaborators.length === 0 
            ? '<p>Aucun collaborateur</p>'
            : this.collaborators.map(collaborator => `
                <div class="collaborator-item">
                    <div class="collaborator-avatar">${this.getInitials(collaborator.name)}</div>
                    <div class="collaborator-info">
                        <div class="collaborator-name">${collaborator.name}</div>
                        <div class="collaborator-email">${collaborator.email}</div>
                    </div>
                    <button 
                        onclick="taskManager.removeCollaborator(${collaborator.id})"
                        class="remove-invite">
                        Retirer
                    </button>
                </div>
            `).join('');
    }

    renderPendingInvites() {
        if (!this.pendingInvitesList) return;

        this.pendingInvitesList.innerHTML = this.pendingInvites.length === 0
            ? '<p>Aucune invitation en attente</p>'
            : this.pendingInvites.map(invite => `
                <div class="pending-invite">
                    <div class="pending-invite-email">${invite.email}</div>
                    <div class="pending-invite-status">${invite.status}</div>
                    <button 
                        onclick="taskManager.removeInvite(${invite.id})"
                        class="remove-invite">
                        Annuler
                    </button>
                </div>
            `).join('');
    }

    // Méthodes utilitaires
    isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    getInitials(name) {
        return name
            .split(' ')
            .map(word => word[0])
            .join('')
            .toUpperCase()
            .slice(0, 2);
    }


    async initialize() {
        await this.loadTasks();
        await this.loadCollaborators();
        await this.loadInvitations();
        
        // Render UI elements after data is loaded
        this.renderTasks(); // This also calls renderGantt
        this.renderCollaborators();
        this.renderPendingInvites();
        this.renderAssigneeSelect();
    }

    async loadTasks() {
        const { data: tasks, error } = await supabaseManager.getTasks();
        if (error) {
            console.error('Error loading tasks:', error);
            return;
        }
        this.tasks = tasks;
        this.renderTasks();
    }

    async loadCollaborators() {
        const { data: profiles, error } = await supabaseManager.supabase
            .from('profiles')
            .select('*')
            .not('id', 'eq', supabaseManager.currentUser?.id);
        
        if (error) {
            console.error('Error loading collaborators:', error);
            return;
        }
        this.collaborators = profiles;
        this.renderCollaborators();
        this.renderAssigneeSelect();
    }

    async loadInvitations() {
        const { data: invitations, error } = await supabaseManager.getInvitations();
        if (error) {
            console.error('Error loading invitations:', error);
            return;
        }
        this.pendingInvites = invitations;
        this.renderPendingInvites();
    }

    async addTask() {
        const title = document.getElementById('taskTitle').value;
        const description = document.getElementById('taskDescription').value;
        const dueDate = document.getElementById('dueDate').value;
        const priority = document.getElementById('priority').value;
        const assignToSelect = document.getElementById('assignTo');
        const selectedCollaborators = Array.from(assignToSelect.selectedOptions).map(option => ({
            id: option.value,
            name: option.text.split(' (')[0],
            email: option.text.match(/\((.*?)\)/)[1]
        }));

        const taskData = {
            title,
            description,
            due_date: dueDate,
            priority,
            completed: false
        };

        const { data: newTask, error: taskError } = await supabaseManager.createTask(taskData);
        if (taskError) {
            console.error('Error creating task:', taskError);
            return;
        }

        // Ajouter les assignations
        for (const collaborator of selectedCollaborators) {
            await supabaseManager.assignTask(newTask[0].id, collaborator.id);
        }

        await this.loadTasks();
        this.taskForm.reset();
    }

    async toggleTaskStatus(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            const { error } = await supabaseManager.updateTask(taskId, {
                completed: !task.completed
            });
            
            if (error) {
                console.error('Error updating task status:', error);
                return;
            }
            
            await this.loadTasks();
        }
    }

    async deleteTask(taskId) {
        const { error } = await supabaseManager.deleteTask(taskId);
        if (error) {
            console.error('Error deleting task:', error);
            return;
        }
        await this.loadTasks();
    }

    filterTasks() {
        let filteredTasks = [...this.tasks];
        
        // Filtre par statut
        const statusFilter = this.statusFilter.value;
        if (statusFilter !== 'all') {
            filteredTasks = filteredTasks.filter(task => 
                statusFilter === 'completed' ? task.completed : !task.completed
            );
        }

        // Filtre par priorité
        const priorityFilter = this.priorityFilter.value;
        if (priorityFilter !== 'all') {
            filteredTasks = filteredTasks.filter(task => 
                task.priority === priorityFilter
            );
        }

        return filteredTasks;
    }

    formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    renderTasks() {
        const filteredTasks = this.filterTasks();
        
        this.tasksList.innerHTML = filteredTasks.length === 0 
            ? '<p>Aucune tâche à afficher</p>'
            : filteredTasks.map(task => this.createTaskElement(task)).join('');
        
        this.renderGantt();
    }

    renderGantt() {
        // Trouver la date la plus proche et la plus éloignée
        if (this.tasks.length === 0) {
            this.ganttTimeline.innerHTML = '<p>Aucune tâche à afficher</p>';
            this.ganttBody.innerHTML = '';
            return;
        }

        const dates = this.tasks.map(task => new Date(task.dueDate));
        const minDate = new Date(Math.min(...dates));
        const maxDate = new Date(Math.max(...dates));

        // Générer les dates pour l'en-tête
        const timeline = [];
        const currentDate = new Date(minDate);
        while (currentDate <= maxDate) {
            timeline.push(new Date(currentDate));
            currentDate.setDate(currentDate.getDate() + 1);
        }

        // Rendre l'en-tête du timeline
        this.ganttTimeline.innerHTML = timeline.map(date => `
            <div class="gantt-day">${date.toLocaleDateString('fr-FR', {day: 'numeric', month: 'short'})}</div>
        `).join('');

        // Rendre les barres de tâches
        this.ganttBody.innerHTML = this.tasks.map(task => {
            const taskDate = new Date(task.dueDate);
            const daysDiff = Math.floor((taskDate - minDate) / (1000 * 60 * 60 * 24));
            const left = daysDiff * 50 + 200; // 50px par jour + 200px pour le label

            return `
                <div class="gantt-task">
                    <div class="gantt-task-label">${task.title}</div>
                    <div class="gantt-task-bar priority-${task.priority}" 
                         style="left: ${left}px; width: 50px;">
                        ${this.formatDate(task.dueDate)}
                    </div>
                </div>
            `;
        }).join('');
    }

    createTaskElement(task) {
        const assignees = task.assignedTo.map(user => `
            <div class="task-assignee">
                <span class="assignee-avatar">${this.getInitials(user.name)}</span>
                <span class="assignee-name">${user.name}</span>
            </div>
        `).join('');

        return `
            <div class="task-item priority-${task.priority} ${task.completed ? 'completed' : ''}">
                <div class="task-info">
                    <div class="task-title">${task.title}</div>
                    <div class="task-description">${task.description}</div>
                    <div class="task-meta">
                        <span>Échéance: ${this.formatDate(task.dueDate)}</span>
                        <span>Priorité: ${task.priority}</span>
                    </div>
                    <div class="task-assignees">
                        ${task.assignedTo.length ? `
                            <div class="assignees-label">Assigné à:</div>
                            <div class="assignees-list">
                                ${assignees}
                            </div>
                        ` : '<div class="no-assignees">Aucun collaborateur assigné</div>'}
                    </div>
                </div>
                <div class="task-actions">
                    <button 
                        onclick="taskManager.toggleTaskStatus(${task.id})"
                        class="complete-btn">
                        ${task.completed ? 'Annuler' : 'Terminer'}
                    </button>
                    <button 
                        onclick="taskManager.deleteTask(${task.id})"
                        class="delete-btn">
                        Supprimer
                    </button>
                </div>
            </div>
        `;
    }
}

// Initialisation du gestionnaire de tâches après l'authentification
supabaseManager.supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'SIGNED_IN') {
        window.taskManager = new TaskManager();
        window.taskManager.initialize();
        console.log('Application de planification initialisée avec succès!');
    } else if (event === 'SIGNED_OUT') {
        window.location.reload();
    }
});
