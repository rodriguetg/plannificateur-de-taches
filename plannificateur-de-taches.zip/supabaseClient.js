import { supabase } from './config.js';

export class SupabaseManager {
    constructor() {
        this.supabase = supabase;
        this.currentUser = null;
        this.onAuthStateChange();
    }

    async onAuthStateChange() {
        supabase.auth.onAuthStateChange((event, session) => {
            this.currentUser = session?.user || null;
            if (event === 'SIGNED_IN') {
                this.createProfile(this.currentUser);
            }
        });
    }

    async createProfile(user) {
        const { data, error } = await supabase
            .from('profiles')
            .upsert({
                id: user.id,
                email: user.email,
                name: user.email.split('@')[0],
                updated_at: new Date()
            });

        if (error) console.error('Error creating profile:', error);
        return { data, error };
    }

    async signUp(email, password) {
        try {
            // Basic validation
            if (!email || !password) {
                return { 
                    error: { message: 'Email and password are required' }
                };
            }

            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                return {
                    error: { message: 'Please enter a valid email address' }
                };
            }

            // Password validation
            if (password.length < 6) {
                return {
                    error: { message: 'Password must be at least 6 characters long' }
                };
            }

            const { data, error } = await supabase.auth.signUp({
                email,
                password,
                options: {
                    emailRedirectTo: window.location.origin,
                    data: {
                        name: email.split('@')[0],
                        email: email
                    }
                }
            });

            if (error) {
                throw error;
            }

            return { data, error };
        } catch (error) {
            console.error('Error in signUp:', error);
            return { error };
        }
    }

    async signIn(email, password) {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password
        });
        return { data, error };
    }

    async signOut() {
        const { error } = await supabase.auth.signOut();
        return { error };
    }

    // Gestion des tâches
    async createTask(taskData) {
        const { data, error } = await supabase
            .from('tasks')
            .insert([{
                ...taskData,
                created_by: this.currentUser.id
            }])
            .select();

        if (error) console.error('Error creating task:', error);
        return { data, error };
    }

    async getTasks() {
        const { data, error } = await supabase
            .from('tasks')
            .select(`
                *,
                task_assignments (
                    user_id,
                    profiles (
                        name,
                        email,
                        avatar_url
                    )
                )
            `)
            .order('created_at', { ascending: false });

        if (error) console.error('Error fetching tasks:', error);
        return { data, error };
    }

    async updateTask(taskId, updates) {
        const { data, error } = await supabase
            .from('tasks')
            .update(updates)
            .eq('id', taskId)
            .select();

        if (error) console.error('Error updating task:', error);
        return { data, error };
    }

    async deleteTask(taskId) {
        const { error } = await supabase
            .from('tasks')
            .delete()
            .eq('id', taskId);

        if (error) console.error('Error deleting task:', error);
        return { error };
    }

    // Gestion des assignations
    async assignTask(taskId, userId) {
        const { data, error } = await supabase
            .from('task_assignments')
            .insert([{
                task_id: taskId,
                user_id: userId
            }])
            .select();

        if (error) console.error('Error assigning task:', error);
        return { data, error };
    }

    async removeAssignment(taskId, userId) {
        const { error } = await supabase
            .from('task_assignments')
            .delete()
            .match({ task_id: taskId, user_id: userId });

        if (error) console.error('Error removing assignment:', error);
        return { error };
    }

    // Gestion des invitations
    async sendInvitation(email) {
        const { data, error } = await supabase
            .from('invitations')
            .insert([{
                email,
                invited_by: this.currentUser.id
            }])
            .select();

        if (error) console.error('Error sending invitation:', error);
        return { data, error };
    }

    async getInvitations() {
        const { data, error } = await supabase
            .from('invitations')
            .select('*')
            .eq('invited_by', this.currentUser.id)
            .order('created_at', { ascending: false });

        if (error) console.error('Error fetching invitations:', error);
        return { data, error };
    }

    async updateInvitationStatus(invitationId, status) {
        const { data, error } = await supabase
            .from('invitations')
            .update({ status })
            .eq('id', invitationId)
            .select();

        if (error) console.error('Error updating invitation:', error);
        return { data, error };
    }
}

export const supabaseManager = new SupabaseManager();
