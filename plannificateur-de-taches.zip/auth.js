import { supabaseManager } from './supabaseClient.js';

class AuthUI {
    constructor() {
        this.authContainer = null;
        this.appContainer = document.querySelector('.container');
        this.setupAuthUI();
    }

    setupAuthUI() {
        // Cacher l'application principale
        if (this.appContainer) {
            this.appContainer.style.display = 'none';
        }

        // Créer et ajouter le conteneur d'authentification
        this.authContainer = document.createElement('div');
        this.authContainer.className = 'auth-container';
        this.authContainer.innerHTML = `
            <div class="auth-box">
                <h2>Connexion</h2>
                <form id="authForm">
                    <div class="form-group">
                        <input type="email" id="authEmail" placeholder="Email" required>
                    </div>
                    <div class="form-group">
                        <input type="password" id="authPassword" placeholder="Mot de passe" required>
                    </div>
                    <div class="auth-buttons">
                        <button type="submit" id="signInBtn">Se connecter</button>
                        <button type="button" id="signUpBtn">S'inscrire</button>
                    </div>
                    <div id="authMessage" class="auth-message"></div>
                </form>
            </div>
        `;

        document.body.insertBefore(this.authContainer, document.body.firstChild);
        this.addAuthListeners();
    }

    addAuthListeners() {
        const authForm = document.getElementById('authForm');
        const signUpBtn = document.getElementById('signUpBtn');
        const authMessage = document.getElementById('authMessage');

        authForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('authEmail').value;
            const password = document.getElementById('authPassword').value;

            try {
                const { data, error } = await supabaseManager.signIn(email, password);
                if (error) throw error;
                this.onAuthSuccess();
            } catch (error) {
                authMessage.textContent = error.message;
                authMessage.className = 'auth-message error';
            }
        });

        signUpBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            const email = document.getElementById('authEmail').value;
            const password = document.getElementById('authPassword').value;

            if (!email || !password) {
                authMessage.textContent = 'Veuillez remplir tous les champs';
                authMessage.className = 'auth-message error';
                return;
            }

            // Validation du mot de passe
            if (password.length < 6) {
                authMessage.textContent = 'Le mot de passe doit contenir au moins 6 caractères';
                authMessage.className = 'auth-message error';
                return;
            }

            // Validation de l'email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                authMessage.textContent = 'Veuillez entrer une adresse email valide';
                authMessage.className = 'auth-message error';
                return;
            }

            try {
                authMessage.textContent = 'Création du compte...';
                authMessage.className = 'auth-message';
                
                const { data, error } = await supabaseManager.signUp(email, password);
                console.log('Sign up response:', { data, error });
                
                if (error) {
                    console.error('Sign up error details:', error);
                    let errorMessage = 'Erreur lors de la création du compte';
                    
                    if (error.message) {
                        if (error.message.includes('email') && error.message.includes('taken')) {
                            errorMessage = 'Cette adresse email est déjà utilisée';
                        } else if (error.message.includes('valid') && error.message.includes('email')) {
                            errorMessage = 'Veuillez entrer une adresse email valide';
                        } else if (error.message.includes('password')) {
                            errorMessage = 'Le mot de passe doit contenir au moins 6 caractères';
                        } else {
                            errorMessage = error.message;
                        }
                    }
                    
                    authMessage.textContent = errorMessage;
                    authMessage.className = 'auth-message error';
                    return;
                }

                if (data?.user) {
                    authMessage.textContent = 'Inscription réussie ! Vérifiez votre email pour confirmer votre compte.';
                    authMessage.className = 'auth-message success';
                    
                    // Clear the form
                    document.getElementById('authEmail').value = '';
                    document.getElementById('authPassword').value = '';
                } else {
                    authMessage.textContent = 'Une erreur inattendue est survenue';
                    authMessage.className = 'auth-message error';
                }
            } catch (error) {
                console.error('Sign up error:', error);
                authMessage.textContent = 'Une erreur est survenue lors de la création du compte';
                authMessage.className = 'auth-message error';
            }
        });
    }

    onAuthSuccess() {
        // Cacher l'interface d'authentification
        this.authContainer.style.display = 'none';
        
        // Afficher l'application principale
        if (this.appContainer) {
            this.appContainer.style.display = 'grid';
        }

        // Initialiser le gestionnaire de tâches
        window.taskManager.initialize();
    }
}

// Styles pour l'interface d'authentification
const style = document.createElement('style');
style.textContent = `
    .auth-container {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background-color: #f0f2f5;
    }

    .auth-box {
        background-color: white;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        width: 100%;
        max-width: 400px;
    }

    .auth-box h2 {
        text-align: center;
        color: var(--primary-color);
        margin-bottom: 1.5rem;
    }

    .auth-buttons {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
    }

    .auth-buttons button {
        flex: 1;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 1rem;
        transition: background-color 0.3s;
    }

    #signInBtn {
        background-color: var(--primary-color);
        color: white;
    }

    #signUpBtn {
        background-color: var(--secondary-color);
        color: var(--text-color);
    }

    .auth-message {
        margin-top: 1rem;
        padding: 0.5rem;
        border-radius: 4px;
        text-align: center;
    }

    .auth-message.error {
        background-color: #fee2e2;
        color: #dc2626;
    }

    .auth-message.success {
        background-color: #dcfce7;
        color: #16a34a;
    }
`;

document.head.appendChild(style);

// Initialiser l'interface d'authentification
const authUI = new AuthUI();

export { authUI };
