# Plannificateur de Tâche

Une application web de gestion de tâches avec authentification, développée avec JavaScript et Supabase.

## Fonctionnalités

- Authentification des utilisateurs (inscription/connexion)
- Validation des formulaires
- Interface en français
- Gestion sécurisée des mots de passe
- Base de données Supabase

## Technologies Utilisées

- HTML5
- CSS3
- JavaScript (Vanilla)
- Supabase (Backend as a Service)

## Installation

1. Clonez le repository
```bash
git clone [url-du-repo]
```

2. Installez les dépendances
```bash
npm install
```

3. Configurez les variables d'environnement
- Créez un fichier `.env` à la racine du projet
- Ajoutez vos clés Supabase

4. Lancez l'application
```bash
# Utilisez un serveur local comme live-server ou http-server
python3 -m http.server 8000
```

## Structure du Projet

- `index.html` - Point d'entrée de l'application
- `styles.css` - Styles de l'application
- `auth.js` - Logique d'authentification
- `script.js` - Logique principale de l'application
- `supabaseClient.js` - Configuration et gestion de Supabase
- `config.js` - Configuration de l'application
